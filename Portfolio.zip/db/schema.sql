CREATE DATABASE contact;

USE contact;

